/*
 *FirstClass.java
 *Programmer: Saurabh Bansal
 *ULID : 819654128
 *Aug 25, 2016
 * 
 *Class: IT 168
 *Lecture Section: 
 *Lecture Instructor: Patricia Mastuda
 *Lab Section: 14
 *Lab Instructor: Saurabh Bansal
 */
package edu.ilstu;

/**
 *A first program rearranging statements
 * 
 *@author Saurabh Bansal
 *
 */
public class FirstClass
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		
		System.out.println("Welcome to Java programming!");
		System.out.println("Java rules!");
        System.out.print("I am 30 years old.\n");
        System.out.print("My name is Saurabh Bansal.\n");
        System.out.print("Awesome job!\n");
        System.out.print("\nGoodbye!");

	}

}
