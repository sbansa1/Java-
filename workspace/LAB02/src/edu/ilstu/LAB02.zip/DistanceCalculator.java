/*
 *DistanceCalculator.java
 *Programmer: Saurabh Bansal
 *ULID : 819654128
 *Aug 25, 2016
 * 
 *Class: IT 168
 *Lecture Section: 
 *Lecture Instructor: Patricia Mastuda
 *Lab Section: 14
 *Lab Instructor: Saurabh Bansal
 */
package edu.ilstu;

/**
 *Program to calculate the distance
 * 
 *@author Saurabh Bansal
 *
 */
public class DistanceCalculator
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		int speed = 20;
		int distance = 0;
		int time = 10;
		
	 distance = (speed * time);
	 System.out.println("Total Distance Travelled " + " " + distance);

	}

}
